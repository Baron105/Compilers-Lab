#include <stdio.h>
#include "y.tab.h"

int main()
{
    yyparse();
    return 0;
}