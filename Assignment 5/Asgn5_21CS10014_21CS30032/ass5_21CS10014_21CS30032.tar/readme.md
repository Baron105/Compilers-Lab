# Instuctions to run the code

- To get the executable file a.out run `make` command in the terminal.
- To run the executable file run `./a.out` in the terminal. Now you can enter the input code and get the output.
- To make testing easier we have provided some test files. To run them with the executable file run `make test` in the terminal.
- To remove the executable file and all the object files run `make clean` in the terminal.
