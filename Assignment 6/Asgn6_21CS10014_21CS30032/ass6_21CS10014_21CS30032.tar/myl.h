#ifndef __MYL_H
#define __MYL_H
#define ERR 0
#define OK 1
int printStr(char *);
int printInt(int);
int readInt(int *); // Usual meaning as specified in Assignment #2
int printFlt(float);
int readFlt(float *); // Usual meaning as specified in Assignment #2
#endif