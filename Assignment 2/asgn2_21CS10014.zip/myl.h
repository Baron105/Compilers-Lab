// Header file for Assignment 2: Name it as myl.h

#ifndef _MYL_H
#define _MYL_H
#define ERR 0
#define OK 1
int printStr(char *);
int printInt(int);
int readInt(int *);
int readFlt(float *);
int printFlt(float);
#endif