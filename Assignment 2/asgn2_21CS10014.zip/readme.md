# This is a guide as to how to use the program

## Note: Linux bash and the gcc compiler are required to run this program

run ```make``` to generate all the required assembly files and executables

run ```make clean``` to remove all the generated files

for testing purposes, run ```./a.out``` to run the main program

the main program has prompts to guide the user through the program
